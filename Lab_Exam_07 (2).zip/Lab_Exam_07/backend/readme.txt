npm init -y
npm i express nodemon mongoose core
database-db.js
connect database-db.js

C:\Program Files\MongoDB\Server\4.2\bin

use tvshowroom

db.televisions.insert({"id":101, "modelName":"AC006","brand":"Samsung","price": 30000,"size": 8});

db.televisions.insert({"id":102, "modelName":"AC008","brand":"Sony","price": 40000,"size": 15});

db.televisions.insert({"id":103, "modelName":"AC010","brand":"Airtel","price": 60000,"size": 12});

db.televisions.remove({"id":101});
db.televisions.remove({"id":102});


db.televisions.find();

id: Number,
modelName: String,
brand: String,
price: Number,
size: Number,

index.js

require
database connection
schema
model

crud operations

102
AC008
Sony
40000
15