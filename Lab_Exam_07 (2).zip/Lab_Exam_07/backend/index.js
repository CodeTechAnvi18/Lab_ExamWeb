var express = require("express");
var mongoose = require("mongoose");
var cors = require("cors");
var db = require("./Database/db.js");

db();
console.log("database connected");

var Schema = mongoose.Schema;

var televisionSchema = new Schema({
  id: Number,
    modelName: String,
  brand: String,
  price: Number,
  size: Number,
 
});

var televisionModel = mongoose.model("televisions", televisionSchema);

var app = express();
app.use(cors());
app.use(express.json());

app.get("/getdata", async (request, response) => {
  try {
    var result = await televisionModel.find();
    response.send(result);
  } catch (err) {
    response.send(err.message);
  }
});

app.post("/addData", async (request, response) => {
  try {
    var result = televisionModel(request.body);
    var ans = await result.save();
    response.send("data inserted");
  } catch (err) {
    response.send(err.message);
  }
});

app.put("/update/:id", async (request, response) => {
  try {
    await televisionModel.updateOne(
      { id: request.params.id },
      { $set: request.body }
    );
    response.send(request.params.id + "Updated ");
  } catch (err) {
    response.send(err.message);
  }
});

app.delete("/delete/:id", async (request, response) => {
  try {
    await televisionModel.deleteOne({ id: request.params.id });
    response.send(request.params.id + "deleted");
  } catch (err) {
    response.send(err.message);
  }
});
app.listen(2000);

// app.delete("/tvdelete/:tid", async (req, res) => {
//   try {
//     await tvModel.updateOne({ tid: req.params.tid }, req.body);
//     res.send("Record deleted");
//   } catch (err) {
//     res.send(err.message);
//   }
// });