import React, { useRef } from "react";

export default function Update() {
  var x1 = useRef();
  var x2 = useRef();
  var x3 = useRef();
  var x4 = useRef();
  var x5 = useRef();
  function f1() {
    var data = {
      name: x2.current.value,
      address: x3.current.value,
      stream: x4.current.value,
      year: x5.current.value,
    };
    data = JSON.stringify(data);
    console.log(data);

    fetch(`http://localhost:9000/update/${x1.current.value}`, {
      method: "PUT",
      body: data,
      headers: { "content-type": "application/json" },
    })
      .then((res) => {
        console.log(res);
        alert("Data Updated Successfully!");
      })
      .catch((err) => {
        console.log(err);
      });
  }
  return (
    <div>
      <input type="text" placeholder="Enter id" ref={x1} /> <br />
      <input type="text" placeholder="Enter Name" ref={x2} /> <br />
      <input type="text" placeholder="Enter Adress" ref={x3} /> <br />
      <input type="text" placeholder="Enter Stream" ref={x4} /> <br />
      <input type="text" placeholder="Enter Year" ref={x5} /> <br />
      <button onClick={f1}>Update</button>
    </div>
  );
}
