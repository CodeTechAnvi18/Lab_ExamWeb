import React, { useRef } from "react";

export default function DataGetap() {
  var x1 = useRef();
  var x2 = useRef();
  var x3 = useRef();
  var i1 = useRef();
  var x4 = useRef();
  function f1() {
    var data = {
      id: i1.current.value,
      modelName: x1.current.value,
      brand: x2.current.value,
      price: x3.current.value,
      size: x4.current.value,
    };
    data = JSON.stringify(data);
    console.log(data);

    fetch("http://localhost:2000/addData", {
      method: "POST",
      body: data,
      headers: { "content-type": "application/json" },
    })
      .then((val) => {
        console.log(val);
        alert("Data Submited Successfully !");
      })
      .catch((err) => {
        console.log(err);
      });
  }
  return (
    <div>
      <input type="text" placeholder="Enter id" ref={i1} /> <br />
      <input type="text" placeholder="Enter ModelName" ref={x1} /> <br />
      <input type="text" placeholder="Enter Brand" ref={x2} /> <br />
      <input type="text" placeholder="Enter Price" ref={x3} /> <br />
      <input type="text" placeholder="Enter Size" ref={x4} /> <br />
      <button onClick={f1}>Submit</button>
    </div>
  );
}
