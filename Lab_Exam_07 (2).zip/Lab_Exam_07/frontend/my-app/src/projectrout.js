import React from "react";
import { createBrowserRouter } from "react-router-dom";
import Data from "./components/Data";
import App from "./components/App";
import Update from "./components/Update";

import Delete from "./components/Delete";
import DataGetap from "./components/DataGetap";

const projectroute = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "datapage",
        element: <Data />,
      },
      {
        path: "getdatapage",
        element: <DataGetap />,
      },
      {
        path: "updatepage",
        element: <Update />,
      },
      {
        path: "deletepage",
        element: <Delete />,
      },
    ],
  },
]);

export default projectroute;
